﻿namespace Renci.SshNet.Common
{
    internal static class Array<T>
    {
        public static readonly T[] Empty = new T[0];
    }
}
