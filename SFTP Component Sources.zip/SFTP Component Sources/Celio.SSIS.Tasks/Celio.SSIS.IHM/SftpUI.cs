﻿using System;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.Windows.Forms;

namespace Celio.SSIS.IHM
{
  public class SftpUI : IDtsTaskUI
  {
    TaskHost taskHost;
    Connections connections;
    public void Initialize(TaskHost taskHost, IServiceProvider serviceProvider)
    {
      this.taskHost = taskHost;
      IDtsConnectionService cs = serviceProvider.GetService(typeof(IDtsConnectionService)) as IDtsConnectionService;
      this.connections = cs.GetConnections();      
    }
    public ContainerControl GetView()
    {
      return new SftpUIForm100(this.taskHost, this.connections);      
    }
    public void Delete(IWin32Window parentWindow)
    {
    }
    public void New(IWin32Window parentWindow)
    {
    }    
  }
}
