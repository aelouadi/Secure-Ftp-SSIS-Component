﻿using System.Windows;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;
using System.Drawing;
using System.ComponentModel;
using System;

namespace Celio.SSIS.IHM
{
  /*
   * This form represents the "Edit" window of ErrorOutputDescription component.
   * The class is instanciated when user click the "Edit" on the component.
   * 
   * It allows user to view and change the component properties.
   */
  public  partial class  SftpUIForm100 : Form
  {
    private TaskHost taskHost;
    private Connections connections;
    private TabControl ConfigTabs;
    private TabPage fileConfigTab;
    private Label label3;
    private Label label2;
    private Label label1;
    private Button okBtn;
    private Button cancelBtn;
    private Label label6;
    private Label label5;
    private Label label4;
    private Label label7;
    private ComboBox cmbTransferType;
    private CheckBox chkDeleteRemoteFile;
    private ComboBox cmbFtpPwd;
    private ComboBox cmbFtpLoging;
    private ComboBox cmbServerAdress;
    private ComboBox cmbLocalPath;
    private ComboBox cmbRemotePattern;
    private ComboBox cmbRemotePath;
        private Label label8;
        private ComboBox cmbDownUp;
        private TabPage serverConfigTab;

    public SftpUIForm100(TaskHost taskHost, Connections connections)
    {
      this.taskHost = taskHost;
      this.connections = connections;
      InitializeComponent();
    }

    private void InitializeComponent()
    {
            this.ConfigTabs = new System.Windows.Forms.TabControl();
            this.fileConfigTab = new System.Windows.Forms.TabPage();
            this.cmbFtpPwd = new System.Windows.Forms.ComboBox();
            this.cmbFtpLoging = new System.Windows.Forms.ComboBox();
            this.cmbServerAdress = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.serverConfigTab = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbDownUp = new System.Windows.Forms.ComboBox();
            this.cmbLocalPath = new System.Windows.Forms.ComboBox();
            this.cmbRemotePattern = new System.Windows.Forms.ComboBox();
            this.cmbRemotePath = new System.Windows.Forms.ComboBox();
            this.chkDeleteRemoteFile = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbTransferType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.ConfigTabs.SuspendLayout();
            this.fileConfigTab.SuspendLayout();
            this.serverConfigTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // ConfigTabs
            // 
            this.ConfigTabs.Controls.Add(this.fileConfigTab);
            this.ConfigTabs.Controls.Add(this.serverConfigTab);
            this.ConfigTabs.Location = new System.Drawing.Point(12, 13);
            this.ConfigTabs.Name = "ConfigTabs";
            this.ConfigTabs.SelectedIndex = 0;
            this.ConfigTabs.Size = new System.Drawing.Size(413, 344);
            this.ConfigTabs.TabIndex = 0;
            // 
            // fileConfigTab
            // 
            this.fileConfigTab.Controls.Add(this.cmbFtpPwd);
            this.fileConfigTab.Controls.Add(this.cmbFtpLoging);
            this.fileConfigTab.Controls.Add(this.cmbServerAdress);
            this.fileConfigTab.Controls.Add(this.label3);
            this.fileConfigTab.Controls.Add(this.label2);
            this.fileConfigTab.Controls.Add(this.label1);
            this.fileConfigTab.Location = new System.Drawing.Point(4, 22);
            this.fileConfigTab.Name = "fileConfigTab";
            this.fileConfigTab.Padding = new System.Windows.Forms.Padding(3);
            this.fileConfigTab.Size = new System.Drawing.Size(405, 318);
            this.fileConfigTab.TabIndex = 0;
            this.fileConfigTab.Text = "Server";
            this.fileConfigTab.UseVisualStyleBackColor = true;
            this.fileConfigTab.Click += new System.EventHandler(this.fileConfigTab_Click_1);
            // 
            // cmbFtpPwd
            // 
            this.cmbFtpPwd.FormattingEnabled = true;
            this.cmbFtpPwd.Location = new System.Drawing.Point(99, 70);
            this.cmbFtpPwd.Name = "cmbFtpPwd";
            this.cmbFtpPwd.Size = new System.Drawing.Size(300, 21);
            this.cmbFtpPwd.TabIndex = 8;
            // 
            // cmbFtpLoging
            // 
            this.cmbFtpLoging.FormattingEnabled = true;
            this.cmbFtpLoging.Location = new System.Drawing.Point(99, 43);
            this.cmbFtpLoging.Name = "cmbFtpLoging";
            this.cmbFtpLoging.Size = new System.Drawing.Size(300, 21);
            this.cmbFtpLoging.TabIndex = 7;
            // 
            // cmbServerAdress
            // 
            this.cmbServerAdress.FormattingEnabled = true;
            this.cmbServerAdress.Location = new System.Drawing.Point(99, 16);
            this.cmbServerAdress.Name = "cmbServerAdress";
            this.cmbServerAdress.Size = new System.Drawing.Size(300, 21);
            this.cmbServerAdress.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Sftp password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sftp login";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "SFtp adress";
            // 
            // serverConfigTab
            // 
            this.serverConfigTab.Controls.Add(this.label8);
            this.serverConfigTab.Controls.Add(this.cmbDownUp);
            this.serverConfigTab.Controls.Add(this.cmbLocalPath);
            this.serverConfigTab.Controls.Add(this.cmbRemotePattern);
            this.serverConfigTab.Controls.Add(this.cmbRemotePath);
            this.serverConfigTab.Controls.Add(this.chkDeleteRemoteFile);
            this.serverConfigTab.Controls.Add(this.label7);
            this.serverConfigTab.Controls.Add(this.cmbTransferType);
            this.serverConfigTab.Controls.Add(this.label6);
            this.serverConfigTab.Controls.Add(this.label5);
            this.serverConfigTab.Controls.Add(this.label4);
            this.serverConfigTab.Location = new System.Drawing.Point(4, 22);
            this.serverConfigTab.Name = "serverConfigTab";
            this.serverConfigTab.Padding = new System.Windows.Forms.Padding(3);
            this.serverConfigTab.Size = new System.Drawing.Size(405, 318);
            this.serverConfigTab.TabIndex = 1;
            this.serverConfigTab.Text = "File";
            this.serverConfigTab.UseVisualStyleBackColor = true;
            this.serverConfigTab.Click += new System.EventHandler(this.serverConfigTab_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Download/Upload";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // cmbDownUp
            // 
            this.cmbDownUp.FormattingEnabled = true;
            this.cmbDownUp.Location = new System.Drawing.Point(106, 137);
            this.cmbDownUp.Name = "cmbDownUp";
            this.cmbDownUp.Size = new System.Drawing.Size(264, 21);
            this.cmbDownUp.TabIndex = 12;
            // 
            // cmbLocalPath
            // 
            this.cmbLocalPath.FormattingEnabled = true;
            this.cmbLocalPath.Location = new System.Drawing.Point(106, 100);
            this.cmbLocalPath.Name = "cmbLocalPath";
            this.cmbLocalPath.Size = new System.Drawing.Size(264, 21);
            this.cmbLocalPath.TabIndex = 11;
            // 
            // cmbRemotePattern
            // 
            this.cmbRemotePattern.FormattingEnabled = true;
            this.cmbRemotePattern.Location = new System.Drawing.Point(106, 62);
            this.cmbRemotePattern.Name = "cmbRemotePattern";
            this.cmbRemotePattern.Size = new System.Drawing.Size(265, 21);
            this.cmbRemotePattern.TabIndex = 10;
            // 
            // cmbRemotePath
            // 
            this.cmbRemotePath.FormattingEnabled = true;
            this.cmbRemotePath.Location = new System.Drawing.Point(106, 22);
            this.cmbRemotePath.Name = "cmbRemotePath";
            this.cmbRemotePath.Size = new System.Drawing.Size(265, 21);
            this.cmbRemotePath.TabIndex = 9;
            // 
            // chkDeleteRemoteFile
            // 
            this.chkDeleteRemoteFile.AutoSize = true;
            this.chkDeleteRemoteFile.Location = new System.Drawing.Point(106, 234);
            this.chkDeleteRemoteFile.Name = "chkDeleteRemoteFile";
            this.chkDeleteRemoteFile.Size = new System.Drawing.Size(134, 17);
            this.chkDeleteRemoteFile.TabIndex = 8;
            this.chkDeleteRemoteFile.Text = "Delete file(s) on source";
            this.chkDeleteRemoteFile.UseVisualStyleBackColor = true;
            this.chkDeleteRemoteFile.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Tranfert type";
            // 
            // cmbTransferType
            // 
            this.cmbTransferType.FormattingEnabled = true;
            this.cmbTransferType.Location = new System.Drawing.Point(106, 179);
            this.cmbTransferType.Name = "cmbTransferType";
            this.cmbTransferType.Size = new System.Drawing.Size(264, 21);
            this.cmbTransferType.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Local Path";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Remote pattern";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Remote Path";
            // 
            // okBtn
            // 
            this.okBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okBtn.Location = new System.Drawing.Point(346, 373);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 23);
            this.okBtn.TabIndex = 1;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(265, 373);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelBtn.TabIndex = 2;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // SftpUIForm100
            // 
            this.ClientSize = new System.Drawing.Size(437, 427);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.ConfigTabs);
            this.Name = "SftpUIForm100";
            this.Text = "Sftp Task";
            this.Load += new System.EventHandler(this.SftpUIForm100_Load);
            this.ConfigTabs.ResumeLayout(false);
            this.fileConfigTab.ResumeLayout(false);
            this.fileConfigTab.PerformLayout();
            this.serverConfigTab.ResumeLayout(false);
            this.serverConfigTab.PerformLayout();
            this.ResumeLayout(false);

    }

    private void fileConfigTab_Click(object sender, System.EventArgs e)
    {

    }

    private void fileConfigTab_Click_1(object sender, System.EventArgs e)
    {

    }

    private void SftpUIForm100_Load(object sender, System.EventArgs e)
    {
      //RemoteHost
      foreach (Variable v in taskHost.Variables)
      {
        if (!v.SystemVariable)
          cmbServerAdress.Items.Add(v.QualifiedName);
      }
      //RemoteLogin
      foreach (Variable v in taskHost.Variables)
      {
        if (!v.SystemVariable)
          cmbFtpLoging.Items.Add(v.QualifiedName);
      }

      //RemotePwd
      foreach (Variable v in taskHost.Variables)
      {
        if(!v.SystemVariable)
        cmbFtpPwd.Items.Add(v.QualifiedName);
     
      }

      //RemotePath
      foreach (Variable v in taskHost.Variables)
      {
        if (!v.SystemVariable)
          cmbRemotePath.Items.Add(v.QualifiedName);
      }
      //RemotePattern
      foreach (Variable v in taskHost.Variables)
      {
        if (!v.SystemVariable)
          cmbRemotePattern.Items.Add(v.QualifiedName);
      }
      //LocalPath
      foreach (Variable v in taskHost.Variables)
      {
        if (!v.SystemVariable)
          cmbLocalPath.Items.Add(v.QualifiedName);
      }
      //TypeTransfert
      
        cmbTransferType.Items.Add("Exact Name"); // get the file with the exact supplied Name.
        cmbTransferType.Items.Add("Last");       // get the most recent file matching the pattern.   
        cmbTransferType.Items.Add("All maching files");  // get all files matching the pattern.

            cmbDownUp.Items.Add("DownLoad");
            cmbDownUp.Items.Add("UpLoad");

        }


    
    private void okBtn_Click(object sender, System.EventArgs e)
    {
          Object selectedItem;
          selectedItem = cmbServerAdress.SelectedItem;
          string host = taskHost.Variables[selectedItem.ToString()].Value.ToString();
          this.taskHost.Properties["Host"].SetValue(this.taskHost, host);

          selectedItem = cmbFtpLoging.SelectedItem;
          string login = taskHost.Variables[selectedItem.ToString()].Value.ToString();
          this.taskHost.Properties["User"].SetValue(this.taskHost, login);

          selectedItem = cmbFtpPwd.SelectedItem;
          string pwd = taskHost.Variables[selectedItem.ToString()].Value.ToString();
          this.taskHost.Properties["Pass"].SetValue(this.taskHost, pwd);

          selectedItem = cmbRemotePath.SelectedItem;
          string remotePath = taskHost.Variables[selectedItem.ToString()].Value.ToString();
          this.taskHost.Properties["RemoteFileLocation"].SetValue(this.taskHost, remotePath);

          selectedItem = cmbRemotePattern.SelectedItem;
          string remotePattern = taskHost.Variables[selectedItem.ToString()].Value.ToString();
          this.taskHost.Properties["FilePatternName"].SetValue(this.taskHost, remotePattern);

          selectedItem = cmbLocalPath.SelectedItem;
          string localPath = taskHost.Variables[selectedItem.ToString()].Value.ToString();
          this.taskHost.Properties["LocalFileLocation"].SetValue(this.taskHost, localPath);

          selectedItem = cmbTransferType.SelectedItem;
          //string typeTransfert = selectedItem.ToString();
          this.taskHost.Properties["FileypeTransfert"].SetValue(this.taskHost, selectedItem);

          selectedItem = cmbServerAdress.SelectedItem;
          bool deletFtpFile = chkDeleteRemoteFile.Checked;
          this.taskHost.Properties["DeleteFileSource"].SetValue(this.taskHost, deletFtpFile);

            selectedItem = cmbDownUp.SelectedItem;
            this.taskHost.Properties["UpDown"].SetValue(this.taskHost, selectedItem);
            this.DialogResult = DialogResult.OK;
    }

    private void cancelBtn_Click(object sender, System.EventArgs e)
    {

    }

    private void serverConfigTab_Click(object sender, System.EventArgs e)
    {

    }

    private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
    {

    }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
