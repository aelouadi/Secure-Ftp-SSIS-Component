﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using  Renci.SshNet.Sftp;

namespace Celio.SSIS.Tasks
{
    class FileList:IEnumerable<SftpFile>
    {
        private SftpFile[] _fileList;

        public FileList()
        {
            //_fileList = new SftpFile[fArray.Length];
            //for(int i = 0;i<fArray.Length;i++)
            //{
            //    _fileList[i] = fArray[i];
            //}
        }

        //FileListEnum IEnumerable.GetEnumerator()
        //{
        //    return (FileListEnum)GetEnumerator();
        //}
        IEnumerator<SftpFile> IEnumerable<SftpFile>.GetEnumerator()
        {
            return (IEnumerator<SftpFile>) GetEnumerator();
        }
        public FileListEnum GetEnumerator()
        {
            return new FileListEnum();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
