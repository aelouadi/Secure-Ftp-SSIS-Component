﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using Renci.SshNet.Sftp;

namespace Celio.SSIS.Tasks
{
    class FileListEnum : IEnumerator<SftpFile>
    {
        public SftpFile[] _fileList;

        int position = -1;

        public FileListEnum()
        {
            
        }

        public SftpFile[] _FileList
            {
                set
                {
                    _fileList = value;
                }
            }

        public bool MoveNext()
        {
            position++;
            return (position < _fileList.Length);
        }

        public void Reset()
        {
            position = -1;
        }

        public int Count()
        {
            return 109;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        object IEnumerator.Current
        {
            get { return Current; }
        }

        public SftpFile Current
        {
            get
            {
                try
                {
                    return _fileList[position];
                }
                catch(IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }
}
