﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.SqlServer.Dts.Runtime;
using System.Collections;
using Renci.SshNet;
using System.Text.RegularExpressions;
using System.Collections.Specialized;
using Renci.SshNet.Sftp;
namespace Celio.SSIS.Tasks
{
  class ServerSession
  {
         String host;
         String username;
         String password;
         String remoteFilePath;
         String localFilePath;
         String remoteFilePattern;
         String shortFileName;
         String fileFullName;
         String fileypeTransfert;
         Boolean deleteFile;
         Regex regex;
         List<SftpFile> list = new List<SftpFile>();
         List<String> filesCollectionName = new List<String>();
         SftpClient sftp;

        public ServerSession()
        { }

        public ServerSession(String host, String username, String password, String remoteFilePath, String localFilePath, String remoteFilePattern, String fileypeTransfert)
        {
            this.host = host;
            this.username = username;
            this.password = password;
            this.remoteFilePath = remoteFilePath;
            this.localFilePath = localFilePath;
            this.remoteFilePattern = remoteFilePattern;
            this.fileypeTransfert = fileypeTransfert;
        }

        private  void configureFileName(IDTSComponentEvents evt)
        {
            string shortFileName = string.Empty;
            try
            {
                switch (fileypeTransfert)
                {
                    case "Exact Name":
                        {
                            if (remoteFilePattern.Length != 0)
                                filesCollectionName.Add(remoteFilePattern);
                        }
                        break;
                    case "Last":
                        {
                            sftp = new SftpClient(host, 22, username, password);
                            sftp.Connect();
                            list = sftp.ListDirectory(this.remoteFilePath).ToList<SftpFile>();

                            DateTime stamp = DateTime.MinValue;
                            foreach (SftpFile fl in list)
                            {
                                Match m = Regex.Match(fl.FullName, remoteFilePattern);
                                if (m.Success)
                                {
                                    if (fl.LastAccessTime.CompareTo(stamp) > 0) { shortFileName = fl.FullName.Substring(fl.FullName.LastIndexOf("/") + 1, fl.FullName.Length - fl.FullName.LastIndexOf("/") - 1); stamp = fl.LastWriteTime; }
                                }
                            }
                            if (shortFileName.Length != 0)
                                filesCollectionName.Add(shortFileName);
                            sftp.Disconnect();
                        }
                        break;
                    case "All maching files":
                        {
                            sftp = new SftpClient(host, 22, username, password);
                            sftp.Connect();
                            list = sftp.ListDirectory(this.remoteFilePath).ToList<SftpFile>();
                            foreach (SftpFile fl in list)
                            {
                                Match m = Regex.Match(fl.FullName, remoteFilePattern);
                                if (m.Success)
                                {

                                    filesCollectionName.Add(fl.FullName.Substring(fl.FullName.LastIndexOf("/") + 1, fl.FullName.Length - fl.FullName.LastIndexOf("/") - 1));
                                }
                            }
                            sftp.Disconnect();
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                throw new Exception("No such Files ," + e.Message);
            }

        }

        public   void Run(string DownUp,IDTSComponentEvents evt)
    {

            bool fireAgain = true;
            
            evt.FireInformation(0, "Me", "Run called ", string.Empty, 0, ref fireAgain);
            this.configureFileName(evt);
            sftp = new SftpClient(host, 22, username, password);
            sftp.Connect();
            try
              {
                evt.FireInformation(0, "Me", "Nbr :"+ filesCollectionName.Count.ToString(), string.Empty, 0, ref fireAgain);
                foreach (String fl in filesCollectionName)
                {
                    evt.FireInformation(0, "me", fl.ToString(), string.Empty, 0, ref fireAgain);
                    string fullLoaclFileName = localFilePath + "\\" + fl.ToString();
                    string fullRemoteFileName= remoteFilePath + fl.ToString();
                    using (var file = File.OpenWrite(fullLoaclFileName))
                    {
                        
                switch(DownUp)
                        {
                            case "DownLoad":
                                sftp.DownloadFile(fullRemoteFileName, file);
                                break;
                            case "UpLoad":
                                sftp.UploadFile(file, fullRemoteFileName);
                                
                                break;
                            default:
                                break;
                        }
                
                    }  
                }
                    if (deleteFile)
                {
                    try
                    {

                    }
                    catch
                    {
                        sftp.Disconnect();
                        throw new Exception("Erreur de suppression du fichier ");                        
                    }
                }
                sftp.Disconnect();
            }
      catch (Exception e)
      {
                sftp.Disconnect();
                evt.FireError(0,"Sftp: Run processing method, ", e.Message, string.Empty, 0);
      }
    }

       
   
    public  void Delete(IDTSComponentEvents evt)
    {
      bool fireAgain = true;
            shortFileName = remoteFilePattern;
            fileFullName = remoteFilePath + "\\" + shortFileName;
      try
      {
        using (var sftp = new SftpClient(host, 22, username, password))
        {
          sftp.Connect();
          sftp.DeleteFile(fileFullName);
          sftp.Disconnect();
        }
      }
      catch (Exception e)
      {
        
      }
    }
  }
}
