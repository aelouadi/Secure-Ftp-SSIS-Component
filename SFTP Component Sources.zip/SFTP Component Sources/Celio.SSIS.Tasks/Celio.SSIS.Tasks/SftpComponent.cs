﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Dts.Runtime;
using System.ComponentModel;
using System.Xml;
using Renci.SshNet.Sftp;


namespace Celio.SSIS.Tasks
{
  [DtsTask
  (
   DisplayName = "Sftp Task",
   IconResource = "Celio.SSIS.Tasks.Sftp.ico",
   UITypeName = "Celio.SSIS.IHM.SftpUI,Celio.SSIS.IHM, Version=1.0.0.0, Culture=neutral, PublicKeyToken=a2fcce0d7389d33f",
   TaskType = "PackageMaintenance",
   TaskContact = "aelouadi@gmail.com; Celio; Call 1452 for any help",
   RequiredProductLevel = DTSProductLevel.None
   )]

  
  public class SftpComponent : Task
  {
      ServerSession serverSession;
      bool fireAgain = true;
      
    
      public SftpComponent()
      {
        //serverSession = new ServerSession(host, user, pass, remoteFileLocation, localFileLocation, filePatternName);
      }  

      public override DTSExecResult Execute(Connections cons, VariableDispenser vars, IDTSComponentEvents events, IDTSLogging log, Object txn)
      {        
        try
        {
            serverSession = new ServerSession(host, user, pass, remoteFileLocation, localFileLocation, filePatternName, fileypeTransfert);
            serverSession.Run(upDown,events);
            return DTSExecResult.Success;
        }
        catch (System.Exception exception)
        { 
          events.FireError(0, "SftpComponent", exception.Message, "", 0);
          return DTSExecResult.Failure;
        }
      }


        public override DTSExecResult Validate(Connections connections, VariableDispenser variableDispenser, IDTSComponentEvents componentEvents, IDTSLogging log)
        {          
          return DTSExecResult.Success;      
        }

        private String host;
        public String Host
        {
          set { host = value; }
          get { return host; }
        }
        private String user;
        public String User
        {
          set { user = value; }
          get { return user; }
        }
        private String pass;
      

        [Category("Security")]
        [PasswordPropertyText(true)]
        public String Pass
        {
          set
            {
                pass = value;
            }
                get { return pass; }
            
        }

        private String filePatternName;
        public String FilePatternName
        {
          set { filePatternName = value; }
          get { return filePatternName; }
        }
        private String remoteFileLocation;
        public String RemoteFileLocation
        {
          set { remoteFileLocation = value; }
          get { return remoteFileLocation; }
        }
        private String localFileLocation;
        public String LocalFileLocation
        {
          set { localFileLocation = value; }
          get { return localFileLocation; }
        }
        bool deleteFileSource;
        public bool DeleteFileSource
        {
          set { deleteFileSource = value; }
          get { return deleteFileSource; }
        }

        private String fileypeTransfert;

        public String FileypeTransfert
        {
            set { fileypeTransfert = value; }
            get { return fileypeTransfert; }
        }
        private String upDown;

        public String UpDown
        {
            set { upDown = value; }
            get { return upDown; }
        }

    }
}
