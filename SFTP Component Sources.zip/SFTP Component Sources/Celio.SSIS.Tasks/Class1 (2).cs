﻿using System;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;
using System.Drawing;
using System.ComponentModel;

public class ihm:Form
{
	public ihm(TaskHost taskHost, Connections connections)
    {
        this.taskHost = taskHost;
        this.connections = connections;
    }
}
