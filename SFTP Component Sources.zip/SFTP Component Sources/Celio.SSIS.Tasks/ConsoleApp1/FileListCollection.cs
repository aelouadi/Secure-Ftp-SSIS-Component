﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using Renci.SshNet.Sftp;

namespace ConsoleApp1
{
    class FileListCollection : IEnumerable<SftpFile>, IEnumerator<SftpFile>
    {

        private int position;
        public List<SftpFile> _fileList { get; set; }
        public IEnumerator<SftpFile> GetEnumerator()
        {
            return (IEnumerator<SftpFile>)this;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator<SftpFile>)this;
        }

        public bool MoveNext()
        {
            position++;
            return (position < _fileList.Count);
        }
        
        public void Reset()
        {
            position = 0;
        }

        object IEnumerator.Current
        {
            get { return (_fileList.ToArray())[position]; }
        }

        public SftpFile Current
        {
            get { return (_fileList.ToArray())[position]; }
        }

        public void Dispose()
        {

        }
    }
}