﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using Renci.SshNet;
using System.Text.RegularExpressions;
using System.Collections.Specialized;
using Renci.SshNet.Sftp;


namespace ConsoleApp1
{
    class Program
    {
        //[sftp] Informations : {host=smart-traffik.com, usr=Celio_ftp ,pass=lan8ooSDiHo7chu, remoteFileLocation=/test/, shortRemoteFileName=EVOKE.csv
    
        static string host = "smart-traffik.com";
        static string username = "celio_ftp";
        static string password = "lahn8ooSDiHo7chu";
        static string remoteFolder = "/prod/";
        static string remoteFilePattern = "-EVOKE-celio-statistiques.csv";
        static string localFolder = "C:\\local";
        static SftpClient sftp;
        static FileListCollection hostdata;
        static int cpt = 0;
        static Regex regex;
   
        static string fileypeTransfert = "Last";
        static List<SftpFile> list = new List<SftpFile>();
        static List<String> filesCollectionName =new List<String>();

        static void Main(string[] args)
        {
            
            
            configureFileName();
            Console.WriteLine("la collection contient " + filesCollectionName.Count());
            foreach (String fl in filesCollectionName)
            {
                Console.WriteLine("list " + fl.ToString());
            }
            
            //sftp.Disconnect();
        }

        private static void configureFileName()
        {
            string shortFileName = string.Empty;
            try
            {
                switch (fileypeTransfert)
                {
                    case "Exact Name":
                        {
                            if (remoteFilePattern.Length != 0)
                                filesCollectionName.Add(remoteFilePattern);
                        }
                        break;
                    case "Last":
                        {
                            sftp = new SftpClient(host, 22, username, password);
                            sftp.Connect();
                            list = sftp.ListDirectory(remoteFolder).ToList<SftpFile>();
                            
                            DateTime stamp = DateTime.MinValue;
                            foreach (SftpFile fl in list)
                            {
                                Match m = Regex.Match(fl.FullName, remoteFilePattern);
                                if (m.Success)
                                {
                                    if (fl.LastAccessTime.CompareTo(stamp) > 0) { shortFileName = fl.FullName.Substring(fl.FullName.LastIndexOf("/")+1, fl.FullName.Length - fl.FullName.LastIndexOf("/")-1); stamp = fl.LastWriteTime; }
                                }
                            }
                            if (shortFileName.Length != 0)
                                filesCollectionName.Add(shortFileName);
                            sftp.Disconnect();
                        }
                        break;
                    case "All maching files":
                        {
                            sftp = new SftpClient(host, 22, username, password);
                            sftp.Connect();
                            list = sftp.ListDirectory(remoteFolder).ToList<SftpFile>();
                            foreach (SftpFile fl in list)
                            {
                                Match m = Regex.Match(fl.FullName, remoteFilePattern);
                                if (m.Success)
                                {

                                    filesCollectionName.Add(fl.FullName.Substring(fl.FullName.LastIndexOf("/") + 1, fl.FullName.Length - fl.FullName.LastIndexOf("/") - 1));
                                }
                            }
                            sftp.Disconnect();
                        }
                        break;
                    default:
                        break;
                }
            }
            catch(Exception e)
            {
                throw new Exception("No such Files ,"+ e.Message);
            }
            
        }
    }
}
